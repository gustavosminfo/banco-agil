"""
Banco Ágil — sistema de atendimento por agentes de IA.
Framework: Agno  |  LLM: Claude Sonnet 4.6  |  UI: Streamlit
"""

__version__ = "1.0.0"
