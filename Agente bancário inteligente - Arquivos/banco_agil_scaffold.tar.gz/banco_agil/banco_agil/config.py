"""
banco_agil/config.py
Configurações centralizadas do Banco Ágil.
"""

from pathlib import Path
from dotenv import load_dotenv

load_dotenv()

# ── Caminhos ────────────────────────────────────────────────────────────────
BASE_DIR    = Path(__file__).resolve().parent.parent
DATA_DIR    = BASE_DIR / "data"
TMP_DIR     = BASE_DIR / "tmp"

TMP_DIR.mkdir(exist_ok=True)

CLIENTES_CSV               = DATA_DIR / "clientes.csv"
SCORE_LIMITE_CSV           = DATA_DIR / "score_limite.csv"
SOLICITACOES_CSV           = DATA_DIR / "solicitacoes_aumento_limite.csv"
SESSION_DB                 = TMP_DIR  / "banco_agil.db"

# ── Modelo LLM ──────────────────────────────────────────────────────────────
# Troque para "claude-haiku-4-5-20251001" para menor custo em testes
MODEL_ID = "claude-sonnet-4-6"

# ── Regras de negócio ────────────────────────────────────────────────────────
MAX_AUTH_ATTEMPTS = 3          # Tentativas de autenticação antes do bloqueio

# ── API de Câmbio (AwesomeAPI — gratuita, sem chave) ────────────────────────
CAMBIO_API_URL = "https://economia.awesomeapi.com.br/json/last/{pair}"
# Exemplos de par: USD-BRL, EUR-BRL, GBP-BRL, BTC-BRL

# ── Mapeamento de nomes de moeda para par AwesomeAPI ─────────────────────────
MOEDA_PARA_PAR: dict[str, str] = {
    "dolar":   "USD-BRL",
    "dólar":   "USD-BRL",
    "usd":     "USD-BRL",
    "euro":    "EUR-BRL",
    "eur":     "EUR-BRL",
    "libra":   "GBP-BRL",
    "gbp":     "GBP-BRL",
    "bitcoin": "BTC-BRL",
    "btc":     "BTC-BRL",
    "iene":    "JPY-BRL",
    "jpy":     "JPY-BRL",
}
